# Nested Navigation with Bottom Bar and Jetpack Compose - Video Tutorial

<p align="center">
  <a href="https://youtu.be/gNzPGI9goU0" align="center">YouTube - Video Tutorial</a>
</p>
<p align="center">
  <img src="https://i.postimg.cc/5tb30C3m/Bottom-bar-nested-nav.png" href="https://youtu.be/gNzPGI9goU0">
</p>
